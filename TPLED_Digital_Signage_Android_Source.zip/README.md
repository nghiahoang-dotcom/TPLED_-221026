# TPLED Digital Signage (Android/Kotlin)

Starter Android Studio project for offline JPG/PNG/MP4 signage playback.

## Features
- Landscape/portrait layouts (follows device orientation; force either in Android settings if needed).
- Import supported media from USB using Android's Storage Access Framework folder picker.
- Remembers the selected USB folder permission and can rescan it when the app opens.
- Copies media into app-private storage, so playback works after USB removal.
- Playlist ordering, image duration, loop, fullscreen playback.
- Optional launch after device boot (subject to Android/OEM background-start restrictions).

## Important USB limitation
Android apps generally cannot silently browse a USB mass-storage drive. The user must choose the USB folder once through the system folder picker and grant access. Android may not notify ordinary apps reliably when a USB storage volume is inserted; this starter auto-rescans the previously granted folder when the app opens and offers a one-tap **Scan USB** action. A fully unattended kiosk setup may require device-owner/kiosk provisioning or OEM-specific APIs. USB-C OTG adapter and host support are required.

## Build APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

For a release APK: **Build > Generate Signed Bundle / APK > APK**, create and securely store a signing key.

## GitHub
1. On GitHub, click **New repository**.
2. Name it `TPLED-Digital-Signage`; choose Private or Public; do not initialize with a README (this project already has one).
3. In this folder, run:
   ```bash
   git init
   git add .
   git commit -m "Initial TPLED Digital Signage Android app"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/TPLED-Digital-Signage.git
   git push -u origin main
   ```
4. Replace `YOUR-USERNAME` with your GitHub username. GitHub authentication may ask you to sign in via browser/token.

## Current starter limitations
- Media formats depend on Android/Media3 decoder support.
- Import uses the selected folder tree; nested folders are scanned recursively.
- Same-name files are skipped if already imported. Remove a playlist item from the app to delete its local copy.
- The boot receiver is best-effort; some Android versions/OEMs block automatic activity launch from boot. For commercial unattended deployment, use a dedicated kiosk device and configure the app as the home app/device owner where supported.
