package vn.tpled.digitalsignage

import org.json.JSONObject

data class MediaItem(val name: String, val path: String, val type: String) {
    fun toJson() = JSONObject().put("name", name).put("path", path).put("type", type)
    companion object {
        fun fromJson(o: JSONObject) = MediaItem(o.getString("name"), o.getString("path"), o.getString("type"))
    }
}
