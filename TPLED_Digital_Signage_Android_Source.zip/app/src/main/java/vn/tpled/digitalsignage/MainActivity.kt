package vn.tpled.digitalsignage

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var listBox: LinearLayout
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                MediaStore.setTree(this, uri)
                importTree(uri)
            } catch (e: Exception) {
                toast("Không cấp được quyền đọc USB: ${e.message}")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        renderList()
        // Best effort: rescan the last folder permission whenever the app opens.
        MediaStore.tree(this)?.let { uri -> lifecycleScope.launch { importTree(uri, quiet = true) } }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
            setBackgroundColor(0xFF081426.toInt())
        }
        val title = TextView(this).apply {
            text = "TPLED DIGITAL SIGNAGE"
            textSize = 23f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER_VERTICAL
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(48)))
        status = TextView(this).apply { textSize = 14f; setTextColor(0xFFB9D6EE.toInt()) }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(42)))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(button("Chọn USB", 0xFF00AEEF.toInt()) { folderPicker.launch(null) }, weightParams())
        buttons.addView(button("Quét USB", 0xFF173D68.toInt()) {
            val uri = MediaStore.tree(this)
            if (uri == null) folderPicker.launch(null) else importTree(uri)
        }, weightParams())
        root.addView(buttons)
        val settings = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        settings.addView(button("Thời lượng ảnh", 0xFF173D68.toInt()) { durationDialog() }, weightParams())
        settings.addView(button(if (MediaStore.loop(this)) "Lặp: BẬT" else "Lặp: TẮT", 0xFF173D68.toInt()) {
            MediaStore.setLoop(this, !MediaStore.loop(this)); buildUi(); renderList()
        }, weightParams())
        root.addView(settings)
        root.addView(button("▶  PHÁT TOÀN MÀN HÌNH", 0xFF00A86B.toInt()) {
            if (MediaStore.playlist(this).isEmpty()) toast("Hãy nhập file JPG/PNG/MP4 trước.")
            else startActivity(Intent(this, PlayerActivity::class.java))
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8); bottomMargin = dp(8) })
        val heading = TextView(this).apply {
            text = "PLAYLIST"; textSize = 16f; setTextColor(0xFFFFFFFF.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(heading, LinearLayout.LayoutParams(-1, dp(34)))
        val scroll = ScrollView(this)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun renderList() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        val items = MediaStore.playlist(this)
        status.text = "${items.size} tệp trong playlist • Ảnh ${MediaStore.duration(this)} giây • ${if (MediaStore.loop(this)) "Lặp liên tục" else "Phát một lượt"}"
        if (items.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "Chưa có nội dung. Cắm USB rồi chọn “Chọn USB”."
                setTextColor(0xFFB9D6EE.toInt()); textSize = 15f; setPadding(0, dp(16), 0, dp(16))
            })
        }
        items.forEachIndexed { index, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(6), dp(8)); setBackgroundColor(0xFF10233D.toInt())
            }
            val label = TextView(this).apply {
                text = "${index + 1}. ${item.name}\n${if (item.type == "video") "MP4 video" else "Ảnh tĩnh"}"
                textSize = 14f; setTextColor(0xFFFFFFFF.toInt())
            }
            row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(smallButton("↑") { moveItem(index, -1) })
            row.addView(smallButton("↓") { moveItem(index, 1) })
            row.addView(smallButton("Xóa") {
                val current = MediaStore.playlist(this)
                if (index in current.indices) {
                    File(current[index].path).delete()
                    current.removeAt(index); MediaStore.savePlaylist(this, current); renderList()
                }
            })
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(6)
            listBox.addView(row, lp)
        }
    }

    private fun moveItem(index: Int, delta: Int) {
        val items = MediaStore.playlist(this); val target = index + delta
        if (target !in items.indices) return
        val tmp = items[index]; items[index] = items[target]; items[target] = tmp
        MediaStore.savePlaylist(this, items); renderList()
    }

    private fun importTree(uri: Uri, quiet: Boolean = false) {
        lifecycleScope.launch {
            status.text = "Đang quét và nhập nội dung USB…"
            val result = withContext(Dispatchers.IO) { MediaStore.importFromTree(this@MainActivity, uri) }
            renderList()
            if (!quiet || result > 0) toast(if (result > 0) "Đã nhập $result tệp mới." else "Không có tệp mới được nhập.")
        }
    }

    private fun durationDialog() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(MediaStore.duration(this@MainActivity).toString())
            hint = "Số giây (1–600)"
        }
        android.app.AlertDialog.Builder(this).setTitle("Thời lượng mỗi ảnh (giây)")
            .setView(input).setNegativeButton("Hủy", null)
            .setPositiveButton("Lưu") { _, _ ->
                val seconds = input.text.toString().toIntOrNull() ?: 10
                MediaStore.setDuration(this, seconds); renderList()
            }.show()
    }

    private fun button(text: String, color: Int, action: () -> Unit) = Button(this).apply {
        this.text = text; setTextColor(0xFFFFFFFF.toInt()); setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
        isAllCaps = false; textSize = 13f; setOnClickListener { action() }
    }
    private fun smallButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 11f; minWidth = dp(38); setPadding(dp(4), 0, dp(4), 0)
        setOnClickListener { action() }
    }
    private fun weightParams() = LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(6) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onResume() { super.onResume(); if (::listBox.isInitialized) renderList() }
}
