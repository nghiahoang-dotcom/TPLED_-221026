package vn.tpled.digitalsignage

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.File

class PlayerActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private lateinit var image: ImageView
    private lateinit var video: PlayerView
    private var player: ExoPlayer? = null
    private var items: List<MediaItem> = emptyList()
    private var index = 0
    private val handler = Handler(Looper.getMainLooper())
    private val advance = object : Runnable {
        override fun run() {
            if (items.isEmpty()) return
            if (items[index].type == "image") next()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        image = ImageView(this).apply {
            setBackgroundColor(Color.BLACK); scaleType = ImageView.ScaleType.FIT_CENTER; visibility = View.GONE
        }
        video = PlayerView(this).apply {
            useController = false; setShutterBackgroundColor(Color.BLACK); visibility = View.GONE
        }
        root.addView(image, FrameLayout.LayoutParams(-1, -1))
        root.addView(video, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        items = MediaStore.playlist(this)
        if (items.isEmpty()) { finish(); return }
        player = ExoPlayer.Builder(this).build().also { exo ->
            video.player = exo
            exo.repeatMode = Player.REPEAT_MODE_OFF
            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_ENDED && items.getOrNull(index)?.type == "video") next()
                }
            })
        }
        showCurrent()
    }

    private fun showCurrent() {
        if (items.isEmpty()) return
        handler.removeCallbacks(advance)
        val item = items[index]
        if (item.type == "image") {
            video.visibility = View.GONE
            image.visibility = View.VISIBLE
            image.setImageURI(Uri.fromFile(File(item.path)))
            handler.postDelayed(advance, MediaStore.duration(this) * 1000L)
        } else {
            image.visibility = View.GONE
            video.visibility = View.VISIBLE
            player?.apply {
                stop()
                clearMediaItems()
                setMediaItem(ExoMediaItem.fromUri(Uri.fromFile(File(item.path))))
                prepare()
                playWhenReady = true
            }
        }
    }

    private fun next() {
        if (items.isEmpty()) return
        if (index + 1 >= items.size) {
            if (!MediaStore.loop(this)) { finish(); return }
            index = 0
        } else index++
        showCurrent()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        video.player = null
        player?.release(); player = null
        super.onDestroy()
    }
}
