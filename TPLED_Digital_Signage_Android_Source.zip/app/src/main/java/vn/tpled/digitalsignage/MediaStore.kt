package vn.tpled.digitalsignage

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.content.ContentResolver
import org.json.JSONArray
import java.io.File
import java.util.Locale

object MediaStore {
    private const val PREFS = "tpled_settings"
    private const val KEY_LIST = "playlist"
    private const val KEY_TREE = "usb_tree"
    private const val KEY_DURATION = "image_duration"
    private const val KEY_LOOP = "loop_playlist"
    private val supported = setOf("jpg", "jpeg", "png", "mp4")

    fun directory(context: Context): File = File(context.filesDir, "media").apply { mkdirs() }

    fun playlist(context: Context): MutableList<MediaItem> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LIST, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return MutableList(arr.length()) { MediaItem.fromJson(arr.getJSONObject(it)) }
            .filter { File(it.path).exists() }.toMutableList()
    }

    fun savePlaylist(context: Context, items: List<MediaItem>) {
        val arr = JSONArray()
        items.forEach { arr.put(it.toJson()) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LIST, arr.toString()).apply()
    }

    fun duration(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_DURATION, 10).coerceIn(1, 600)

    fun setDuration(context: Context, seconds: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_DURATION, seconds.coerceIn(1, 600)).apply()
    }

    fun loop(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_LOOP, true)

    fun setLoop(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_LOOP, enabled).apply()
    }

    fun tree(context: Context): Uri? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_TREE, null)?.let(Uri::parse)

    fun setTree(context: Context, uri: Uri) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_TREE, uri.toString()).apply()
    }

    fun importFromTree(context: Context, treeUri: Uri): Int {
        val resolver = context.contentResolver
        val rootId = DocumentsContract.getTreeDocumentId(treeUri)
        val root = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
        val imported = mutableListOf<MediaItem>()
        scan(context, resolver, treeUri, root, imported)
        val existing = playlist(context)
        val known = existing.map { it.name.lowercase(Locale.ROOT) }.toMutableSet()
        var count = 0
        imported.forEach { item ->
            if (known.add(item.name.lowercase(Locale.ROOT))) {
                existing.add(item); count++
            } else {
                // Keep existing media; duplicate filename is deliberately skipped.
            }
        }
        savePlaylist(context, existing)
        return count
    }

    private fun scan(context: Context, resolver: ContentResolver, treeUri: Uri, parent: Uri, output: MutableList<MediaItem>) {
        val id = DocumentsContract.getDocumentId(parent)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, id)
        resolver.query(children, arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        ), null, null, null)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
            while (cursor.moveToNext()) {
                val childId = cursor.getString(idCol)
                val name = cursor.getString(nameCol) ?: continue
                val mime = cursor.getString(mimeCol) ?: ""
                val child = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    scan(context, resolver, treeUri, child, output)
                } else {
                    val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    if (ext in supported) {
                        val dest = File(directory(context), safeName(name))
                        if (!dest.exists()) {
                            try {
                                resolver.openInputStream(child)?.use { input ->
                                    dest.outputStream().use { out -> input.copyTo(out) }
                                }
                            } catch (_: Exception) { dest.delete() }
                        }
                        if (dest.exists() && dest.length() > 0) {
                            val type = if (ext == "mp4") "video" else "image"
                            output.add(MediaItem(name, dest.absolutePath, type))
                        }
                    }
                }
            }
        }
    }

    private fun safeName(name: String): String =
        name.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(120).ifBlank { "media_file" }
}
